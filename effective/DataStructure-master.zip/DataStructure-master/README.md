usage of the software 

cd data
make
./example
