#include "example.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char** argv)
{


	xiabodan_list();
	xiabodan_stack();
	xiabodan_queue();
	xiabodan_recursion();
	xiabodan_sorting();
	
	return 0 ;
}
