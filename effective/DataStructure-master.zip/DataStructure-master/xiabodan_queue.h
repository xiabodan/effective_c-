#ifndef _XIABODAN_QUEUE_H_
#define _XIABODAN_QUEUE_H_

void xiabodan_queue(void );


#endif

