#ifndef _XIABODAN_RECURSION_H_
#define _XIABODAN_RECURSION_H_

void xiabodan_recursion(void);

#endif