#ifndef _XIABODAN_SORTING_H_
#define _XIABODAN_SORTING_H_


void xiabodan_sorting(void);


#endif