#ifndef _XIABODAN_STACK_H_
#define _XIABODAN_STACK_H_

void xiabodan_stack(void);


#endif 